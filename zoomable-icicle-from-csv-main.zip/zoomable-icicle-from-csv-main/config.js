const aggKey = "amount";
// const csvFile = "data/flare.csv";
const csvFile = "data/meseumfloor.csv";


const breakCategories = [["楼层", "Category 1"], ["馆别", "Category 2"], ["文物", "Category 3"]]

const initialOrder = ["楼层", "馆别", "文物"];
const initialLib = "上海博物馆";
// const maxDepth = Math.min(3, breakCategories.length);
const maxDepth =4;