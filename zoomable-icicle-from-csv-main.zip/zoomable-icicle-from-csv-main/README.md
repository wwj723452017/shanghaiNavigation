# zoomable-icicle-from-csv
Build an Icicle based on https://observablehq.com/@d3/zoomable-icicle using a csv as an input.

Moreover, a sortable jquery ui widget can reorder the zoomable analysis axis

# Getting started
As easy as : 
```shellscript
python -m http.server
```

# Next steps
- [x] Plug with dc.js